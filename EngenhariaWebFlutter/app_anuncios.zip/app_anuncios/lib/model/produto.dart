class Produto {
  String nome;
  String informacoes;
  String preco;
  
  Produto(this.nome, this.informacoes, this.preco);
}